﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColdDrinkDispenser
{
    class Program
    {
        static void Main(string[] args)
        {
            string numInput = "";

            Console.WriteLine("Choose an option to insert the coin from the following list:");
            Console.WriteLine("\t1 - nickles(1/20)");
            Console.WriteLine("\t2 - dimes(1/10)");
            Console.WriteLine("\t3 - quarters(1/4)");
            Console.WriteLine("\t4 - pennies(1/100)");
            Console.Write("Your option? ");

            int cleanNum = 0;
            numInput=Console.ReadLine();
            while (!int.TryParse(numInput, out cleanNum) )
            {
                Console.Write("This is not valid input.");
                numInput = Console.ReadLine();
            }

            
            switch (cleanNum)
            {
                case 1:
                    Console.WriteLine("You have selected option = nickles");
                    break;
                case 2:
                    Console.WriteLine("You have selected option = dimes");
                    break;
                case 3:
                    Console.WriteLine("You have selected option = quarters");
                    break;
                case 4:
                    Console.WriteLine("You have selected option = pennies, coin rejected");
                    break;
                default :
                    Console.Write("This is not valid input.");
                    break;
            }

            if (cleanNum > 0 && cleanNum < 4)
            {
                ProductDispenser dispenser = new ProductDispenser();
                Product releasedProduct =dispenser.DispenseProduct(cleanNum);
                Console.WriteLine("Product "+releasedProduct.ProductName+" dispensed, Thank You.");
                Console.ReadKey();
            }
            // Wait for the user to respond before closing.
            Console.Write("Press any key to close console app...");
            Console.ReadKey();
        }
       
    }
}
