using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProductDispensor;


namespace ProductDispensor.Test
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestVerfiyInputStringForProduct()
        {
            string input="3";
            
            Dispensor disepnsor=new Dispensor();
            int result=disepnsor.VerifyInputStringForProduct(input);
            Assert.AreEqual(result.ToString(),input);
        }
    }
}
