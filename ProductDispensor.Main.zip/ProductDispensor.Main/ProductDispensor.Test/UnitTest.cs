using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProductDispensor;


namespace ProductDispensor.Test
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestVerfiyInputStringForProduct()
        {
            string input="3";
            
            Dispensor disepnsor=new Dispensor();
            int result=disepnsor.VerifyInputStringForProduct(input);
            Assert.AreEqual(result.ToString(),input);
        }
        [TestMethod]
        public void VerifyCoinsSize()
        {
            string coinType="nickles";
            int actual=30;
            Dispensor disepnsor=new Dispensor();
            int result= disepnsor.VerifyCoinSize(coinType);
            Assert.AreEqual(result,actual);
        }
        [TestMethod]
        public void VerifyCoinsWidth()
        {
            string coinType="dimes";
            int actual=50;
            Dispensor disepnsor=new Dispensor();
            int result=disepnsor.VerifyCoinWeight(coinType);
            Assert.AreEqual(result,actual);
        }
    }
}
