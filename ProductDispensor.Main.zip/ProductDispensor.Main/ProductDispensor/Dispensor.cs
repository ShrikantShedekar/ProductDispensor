﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProductDispensor
{
    public class Dispensor
    {
        List<Product> productsList = new List<Product>();
        public Product DispenseProduct(decimal enteredMoney)
        {
            string numInput = "";
            this.InitializeProducts();

            Console.WriteLine("Select Products:");
            Console.WriteLine("\t1 - cola");
            Console.WriteLine("\t2 - chips");
            Console.WriteLine("\t3 - candy");
            Console.Write("Your option? ");
            numInput = Console.ReadLine();

             int cleanNum = this.VerifyInputStringForProduct(numInput);
            Product prod = new Product();
            switch (cleanNum)
            {
                case 1:
                    prod = productsList.Where(i => i.ProductId == 1).FirstOrDefault(); 
                    return prod;
                case 2:
                    prod = productsList.Where(i => i.ProductId == 2).FirstOrDefault(); 
                    return prod;
                case 3:
                    prod = productsList.Where(i => i.ProductId == 3).FirstOrDefault(); 
                    return prod;
                default:
                    return prod;
            }
            
        }

        public int VerifyInputStringForProduct(string numInput)
        {
            int cleanNum = 0;
            while (!int.TryParse(numInput, out cleanNum) || (cleanNum<0 && cleanNum >3))
            {
                Console.Write("This is not valid input.");
                numInput = Console.ReadLine();
                
            }  
            return cleanNum; 
        }

        private void InitializeProducts()
        {
            

            Product ColaProduct = new Product();
            ColaProduct.ProductId = 1;
            ColaProduct.ProductName = "Cola";
            ColaProduct.Cost = Convert.ToDecimal(1.00);
            productsList.Add(ColaProduct);

            Product ChipsProduct = new Product();
            ChipsProduct.ProductId = 2;
            ChipsProduct.ProductName = "Chips";
            ChipsProduct.Cost = Convert.ToDecimal(0.50);
            productsList.Add(ChipsProduct);

            Product CandyProduct = new Product();
            CandyProduct.ProductId = 3;
            CandyProduct.ProductName = "Candy";
            CandyProduct.Cost = Convert.ToDecimal(0.65);
            productsList.Add(CandyProduct);

        }
    }
}
